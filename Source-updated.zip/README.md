# SETUP đơn giản với .env 
## Source code by @_hn6 
### SETUP kênh thoại "join to create" để giới hạn là 1 người để tránh bị lỗi
### SETUP kênh "Confession" thành không thể gửi tin nhắn nhưng được gửi tin nhắn trong chủ đề 
### SETUP kênh tạo confession 
### Để bot hoạt động tốt nhất, hãy để bot dưới quyền quản trị viên (permission = 8)

- BOT cần các thư viện tại file "requirements.txt" để có thể hoạt động.

-   (;_;)
-  /|   |\
-   || ||